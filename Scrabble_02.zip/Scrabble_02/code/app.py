from classes.player_interface import PlayerInterface

interface = PlayerInterface((960, 960), 15, "Scrabble")
## Execução do protótipo (interface gráfica)

Para executar o protótipo da interface gráfica, dentro da pasta code/, execute:

- python app.py (para windows)

- python3 app.py (para sistemas Linux)


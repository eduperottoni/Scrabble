class GameConfig:
    def __init__(self, local_player: Player, remote_player: Player, board):
        pass